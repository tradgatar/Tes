#pragma once

#define HTTP_SERVER "216.146.27.222"
#define HTTP_PORT 80

#define TFTP_SERVER "216.146.27.222"
